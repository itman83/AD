<div id="0" style="display:block;"  align="left" class="message_box" >
<h1>Please Select City</h1> 

</div>